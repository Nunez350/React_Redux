var util = require('util');
util.log('Timestamped message.');