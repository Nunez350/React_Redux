process.chdir('/Users/rohanrajore');
console.log(process.cwd());