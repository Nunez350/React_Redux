
const data1 = require(__dirname + '/data.json');

console.log(require.cache);
