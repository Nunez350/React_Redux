console.log('Hello World');  
let text = 'NodeJS';
console.log('Hello %s', text);  

const name = 'John';  
console.warn(`Don't mess with me ${name}!`);   


console.error(new Error('Hell! This is a wrong method.'));  


