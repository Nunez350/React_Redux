module.exports = function () {
    return {
        something: 123,
        somethingElse: 789
    };
};