exports.a = function () {
    console.log('a called');
};

exports.b = function () {
    console.log('b called');
};