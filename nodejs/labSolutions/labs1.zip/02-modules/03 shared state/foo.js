module.exports = {
    something: 123
};