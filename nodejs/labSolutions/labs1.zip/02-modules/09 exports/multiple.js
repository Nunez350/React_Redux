module.exports.first = 'first export';
module.exports.second = 'second export';
exports.third = 'third export';
