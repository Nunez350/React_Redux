const ourPromise = new Promise(function(resolve, reject) {});

const ourOtherPromise = new Promise((resolve, reject) => {});
