let fs = require('fs')
let zlib = require('zlib')

let file = process.argv[1];

fs.createReadStream(file)
    .pipe(zlib.createGzip())
    .pipe(fs.createWriteStream(file + '.gz'))
    .on('finish', function () {
        console.log('file successfully compressed')
    })