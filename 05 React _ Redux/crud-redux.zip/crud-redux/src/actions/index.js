export {
    addPost, deletePost, editPost
} from './postActions';