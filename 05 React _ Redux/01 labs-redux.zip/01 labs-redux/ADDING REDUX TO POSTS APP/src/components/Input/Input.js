import React from 'react';
import './Input.css'

const Input = (props) => {

    let inputElement = null;
    let inputClasses = ['InputElement'];

    if (props.invalid && props.shouldValidate && props.touched) {
        inputClasses.push('Invalid');
    }

    //Error Messages
    let validationError = null;
    if (props.invalid && props.touched) {
        validationError = <p className={'ValidationError'}>Please enter a valid {props.field}</p>;
    }

    switch (props.elementtype) {
        case ('input'):
            inputElement = <input
                className={inputClasses.join(' ')}
                {...props.elementconfig}
                value={props.value}
                onChange={props.changed} />;
            break;
        case ('textarea'):
            inputElement = <textarea
                className={inputClasses.join(' ')}
                {...props.elementconfig}
                value={props.value}
                onChange={props.changed} />;
            break;
        case ('select'):
            inputElement = <select
                className={inputClasses.join(' ')}
                {...props.elementconfig}
                value={props.value}
                onChange={props.changed}>
                {props.elementconfig.options.map(option => {
                    return <option key={option.value} value={option.value}>{option.displayValue}</option>
                })}
            </select>;
            break;
        default:
            inputElement = <input
                className={inputClasses.join(' ')}
                {...props.elementconfig}
                value={props.value} />;
            break;
    }

    return (
        <div className={'Input'}>
            <label className={'Label'}>{props.label}</label>
            {inputElement}
            {validationError}
        </div>
    )
}

export default Input;