import React, { Component } from 'react';
import './Posts.css'
import Post from '../../../components/Post/Post'
import { Link , Route} from 'react-router-dom'
import FullPost from '../FullPost/FullPost'
import {connect} from 'react-redux'
import * as postActions from '../../../store/actions/posts'

class Posts extends Component {


    componentDidMount() {
       
        this.props.onFetchPosts();
    }

    postClickedHandler(id) {
        this.props.history.push('/posts' + id);
    }

    render() {
        let posts = <p style={{ textAlign: "center" }}>Something went wrong</p>
        if (this.props.posts) {
           
            posts = this.props.posts.map((post) => {
                return (
                    <Link to={'/posts/' + post.id} key={post.id}>
                        <Post
                            title={post.title}
                            author={post.author}
                            clicked={this.postClickedHandler.bind(this, post.id)} />
                    </Link>
                )
            });
        }

        return (
            <div>
                <section className="Posts">
                    {posts}
                </section>
                <Route path={this.props.match.url + '/:id'} exact component={FullPost} />
            </div>
        )
    }
}

const mapStateToProps = state => {
  //  console.log(state);
    return {
        posts: state.posts.posts,
        loading: state.posts.loading,
        error: state.posts.error
    };
};

const mapDispatchToProps = dispatch => {
    return {
        onFetchPosts: () => dispatch( postActions.fetchPosts() )
    };
};

export default connect( mapStateToProps, mapDispatchToProps )(Posts);