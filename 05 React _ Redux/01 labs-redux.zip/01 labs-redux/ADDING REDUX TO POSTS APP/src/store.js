import {createStore} from 'redux';
import reducer from '';

const store = createStore(reducer);


export default store;