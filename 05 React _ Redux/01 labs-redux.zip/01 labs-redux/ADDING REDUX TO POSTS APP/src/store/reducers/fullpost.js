import * as actionTypes from '../actions/actionTypes';


const initialState = {
   post: {},
   loading: false,
   error: false,
   deleteSuccess: false
};

const updateObject = (oldObject, updatedProperties) => {
    return {
        ...oldObject,
        ...updatedProperties
    };
};

const fetchPostsStart = ( state, action ) => {
    return updateObject( state, { loading: true } );
};

const fetchPostsSuccess = ( state, action ) => {
    return updateObject( state, {
        post: action.post,
        loading: false
    } );
};

const fetchPostsFail = ( state, action ) => {
    return updateObject( state, { loading: false , error: true} );
};

const deletePost = ( state, action ) => {
    return updateObject( state, { loading: false , error: true, deleteSuccess: true} );
};

const reducer = ( state = initialState, action ) => {
    switch ( action.type ) {
        case actionTypes.FETCH_FULL_POST_START: return fetchPostsStart( state, action );
        case actionTypes.FETCH_FULL_POST_SUCCESS: return fetchPostsSuccess( state, action );
        case actionTypes.FETCH_FULL_POST_FAIL: return fetchPostsFail( state, action );
        case actionTypes.DELETE_POST: return deletePost( state, action );
        default: return state;
    }
};

export default reducer;