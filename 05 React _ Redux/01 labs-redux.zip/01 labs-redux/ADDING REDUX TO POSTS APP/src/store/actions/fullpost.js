import * as actionTypes from './actionTypes';
import axios from '../../axios';

export const fetchFullPostStart = () => {
    return {
        type: actionTypes.FETCH_FULL_POST_START
    }
}

export const fetchFullPostSuccess = (post) => {
    return {
        type: actionTypes.FETCH_FULL_POST_SUCCESS,
        post: post

    }
}

export const fetchFullPostsFail = (error) => {
    return {
        type: actionTypes.FETCH_FULL_POST_FAIL,
        error: error
        
    }
}

export const fetchPost = (id) => {

    console.log('fetch1 action');
    return dispatch => {
        dispatch(fetchFullPostStart());
        axios.get( '/posts/' + id)
            .then( res => {
                const post = res.data;
                dispatch(fetchFullPostSuccess(post));
            } )
            .catch( err => {
                dispatch(fetchFullPostsFail(err));
            } );
    };
}

export const deletePost = (id) => {

    console.log('delete action');
    return dispatch => {
      
        axios.delete( '/posts/' + id)
            .then( res => {
                const data = res.data;
               console.log('post deleted success! ',data);
            } )
    };
}