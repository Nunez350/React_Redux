import * as actionTypes from './actionTypes';
import axios from '../../axios';

export const fetchPostsStart = () => {
    return {
        type: actionTypes.FETCH_POSTS_START
    }
}

export const fetchPostsSuccess = (posts) => {
    return {
        type: actionTypes.FETCH_POSTS_SUCCESS,
        posts: posts

    }
}

export const fetchPostsFail = (error) => {
    return {
        type: actionTypes.FETCH_POSTS_FAIL,
        error: error
        
    }
}

export const fetchPosts = () => {

    console.log('action');
    return dispatch => {
        dispatch(fetchPostsStart());
        axios.get( '/posts')
            .then( res => {
                const posts = res.data.slice(0, 6);
                
                const updatedPosts = posts.map(post => {
                    return { ...post, author: 'john' }
                });
                dispatch(fetchPostsSuccess(updatedPosts));
            } )
            .catch( err => {
                dispatch(fetchPostsFail(err));
            } );
    };
}