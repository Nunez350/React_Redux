const { createStore } = require('redux');

const initialState = {
    counter: 0
}

//Actions
let INC_COUNTER = 'INC_COUNTER';
let ADD_COUNTER = 'ADD_COUNTER';


//Action creators
function inc(){
    return { type: INC_COUNTER }
};

function add(x){
    return { type: ADD_COUNTER, value: x }
}


//Reducer
rootReducer = (state = initialState, action) => {
    if (action.type === 'INC_COUNTER') {
        return {
            ...state,
            counter: state.counter + 1
        };
    }

    if (action.type === 'ADD_COUNTER') {
        return {
            ...state,
            counter: state.counter + action.value
        };
    }
    return state;
}
//Store
const store = createStore(rootReducer);
console.log(store.getState());
//Subscription
store.subscribe(()=>{
    console.log(store.getState());
})
//Dispatching Actions
store.dispatch(inc());
store.dispatch(add(10))



