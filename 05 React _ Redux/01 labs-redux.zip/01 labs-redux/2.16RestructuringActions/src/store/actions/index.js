export {
    add,subtract,increment,decrement
} from './counter';

export {
    storeResult, deleteResult
} from './result';