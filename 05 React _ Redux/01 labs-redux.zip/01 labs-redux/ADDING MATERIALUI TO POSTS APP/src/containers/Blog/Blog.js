import React, { Component, lazy, Suspense } from 'react';
import './Blog.css';
import Posts from './Posts/Posts'
import { Route, NavLink, Switch, Redirect } from 'react-router-dom'
import { withStyles, withTheme } from '@material-ui/core/styles';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import Button from '@material-ui/core/Button';
import IconButton from '@material-ui/core/IconButton';
import MenuIcon from '@material-ui/icons/Menu';
// import NewPost from '../Blog/NewPost/NewPost'
const NewPost = lazy(() => import('../Blog/NewPost/NewPost'));



class Blog extends Component {


    render() {
        const styles = {
            root: {
                flexGrow: 1,
            },
            grow: {
                flexGrow: 1,
            },
            menuButton: {
                marginLeft: -12,
                marginRight: 20,
            },
            button: {
                color: 'white',
            }
        };
        return (
            <div className='Blog'>
            <div className={styles.root}>
                <AppBar position="static">
                    <Toolbar>
                        <IconButton className={styles.menuButton} color="inherit" aria-label="Menu">
                            <MenuIcon />
                        </IconButton>
                       
                        <Button className={styles.button} color="primary"><NavLink to='/posts' exact >Posts</NavLink></Button>
                        <Button className={styles.button} color="primary"><NavLink to='/new-post'>New Post</NavLink></Button>
                    </Toolbar>
                </AppBar>
                </div>
                <Switch>

                    <Route path='/new-post' exact render={() => {
                        return <Suspense fallback={<div>Loading...</div>}>
                            <NewPost />
                        </Suspense>
                    }} />
                    <Route path='/posts' component={Posts} />
                    <Redirect from='/' to='/posts' />
                </Switch>

            </div>
        );
    }
}

export default Blog;