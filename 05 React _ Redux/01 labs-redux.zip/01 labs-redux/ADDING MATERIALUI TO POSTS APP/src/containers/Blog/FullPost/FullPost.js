import React, { Component } from 'react';
import './FullPost.css';
import {connect} from 'react-redux'
import * as postActions from '../../../store/actions/fullpost'

class FullPost extends Component {
    
    componentDidMount() {
        this.loadData();
    }

    componentDidUpdate(){
        this.loadData();
    }

    loadData = () => {
        if (this.props.match.params.id) {
            //Preventing infinite loop
            if (!this.props.post || (this.props.post && this.props.post.id !== +this.props.match.params.id)) {
                this.props.onFetchPost(this.props.match.params.id);
            }
        }
    }

    

    render() {
        let post = <p style={{ textAlign: "center" }}>Please select a Post!</p>;
        if (this.props.loading) {
            post = <p style={{ textAlign: "center" }}>Loading...</p>
        }
        if (this.props.post) {
            post = (
                    <div className="FullPost">
                        <h1>{this.props.post.title}</h1>
                        <p>{this.props.post.body}</p>
                        <div className="Edit">
                            <button onClick={() => this.props.onDeletePost(this.props.match.params.id)} className="Delete">Delete</button>
                        </div>
                    </div>

            );
        }

        return post;
    }
}

const mapStateToProps = state => {
   // console.log(state);
    return {
        post: state.fullpost.post,
        loading: state.fullpost.loading,
        error: state.fullpost.error,
        deleted: state.fullpost.deleteSuccess
    };
};

const mapDispatchToProps = dispatch => {
    return {
        onFetchPost: (id) => dispatch( postActions.fetchPost(id) ),
        onDeletePost: (id) => dispatch(postActions.deletePost(id))
    };
};

export default connect(mapStateToProps,mapDispatchToProps)(FullPost);