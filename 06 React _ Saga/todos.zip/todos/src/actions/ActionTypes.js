export const FETCH_TODOS = "FETCH_TODOS";
export const DELETE_TODO = "DELETE_TODO";


